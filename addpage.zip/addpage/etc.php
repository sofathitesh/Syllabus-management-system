<table>
					<tr><td>Batch</td><td><select name="sel"><option value='2011'>2011</option><option value='2012'>2012</option><option value='2013'>2013</option><option value='2014'>2014</option><option value='2015'>2015</option><option value='2016'>2016</option><option value='2017'>2017</option><option value='2018'>2018</option><option value='2019'>2019</option> <option value='2020'>2020</option></select></td></tr>
					</tr>
					<tr>
						<td>Semester</td><td><input type="text" name="t1" placeholder="Enter Semester In Numeric fome(3,4)" required></td>
						</tr>
										<tr>
						<td>Subject(full name)</td><td><input type="text" name="t2" placeholder="Subject(full name)" required></td>
						</tr>
																<tr>
						<td>Subject(Short name)</td><td><input type="text" name="t4" placeholder="short name" required></td>
						</tr> 

										<tr>
						<td>Subject Code</td><td><input type="text" name="t3" placeholder="subject code" required></td>
						</tr>
										<tr>
						<td>Subject Type</td><td><select name="s3"><option value="theory">Theory</option><option value="paritical">Paritical</option></select></td>
						<tr><td>LoadAllocation(Leacture,Theory,Paritical)</td><td><input type="text" name="t17" style='width:20px'><input type="text" name="t18" style='width:20px'><input type="text" name="t19" style='width:20px'></td>
						</tr>
						</tr>
										<tr>
						<td>Marks Distribution(internal,external)</td><td><input type="text" name="t21" style='width:40px' placeholder="internal" required><input type="text" name="t22" style='width:40px' placeholder="external" required></td>
						</tr>
																<tr>
						<td>Total Marks</td><td><input type="text" name="t23" placeholder="Total Marks"  required></td>
						</tr>

										<tr>
						<td>Credits</td><td><input type="text" name="t24" style='width:40px' placeholder="Credits" required></td>
						</tr>
<tr><td>Objectives</td><td><textarea name='t25' rows=10 cols=50 ></textarea></td></tr>
						<tr>
						<td><input type="submit" value="CREATE" name="create"></td>
						</tr>
						
			</table>
				if(strlen($_POST['t1'])>0)
{
	if(strlen($_POST['s2'])>15)
	{
		echo $_POST['s2'];
	if(strlen($_POST['t2'])>8)
	{
		if(strlen($_POST['t4'])>1)
		{
		if(strlen($_POST['t3'])>2)
		{
					if(strlen($_POST['t21'])>0)
					{
						if(strlen($_POST['t22'])>1)
						{
							if(strlen($_POST['t23'])>1)
							{
								if(strlen($_POST['t24'])>0)
								{
			$qry="select * from syllabi where branch='".$_POST['s2']."' AND subject='".$_POST['t2']."' AND subject_code='".$_POST['t3']."'";
			$result3=mysql_query($qry);
			if(mysql_num_rows($result3)==0)
			{
	$qry="INSERT into syllabi values('".$a."','".$b."','".$c."','".$d."','".$h."','".$e."','".$f."','".$g."','0','".$_POST['t17']."','".$_POST['t18']."','".$_POST['t19']."','".$_POST['t21']."','".$_POST['t22']."','".$_POST['t23']."','".$_POST['t24']."','".$_POST['sel']."','".$_POST['t25']."')";
	$resu=mysql_query($qry);
	echo "<h1>SYLLABUS IS CREATED</h1>";
			}else
			{
				
				error("THIS SUBJECT IS ALREADY ADDED");

	}
}else
{
			error("Enter the Credits");
}
}else
{
			error("Enter the Total Marks");
}
}else
{
			error("Enter the External marks");
}
}else
{
		error("Enter the Internal marks");
}
}else
{
	error("Enter The Subject Code");
}
}
else
{
	error("Enter Short Name");
}

}else
{
	error("Enter the Subject");
}
}else
{
	 error("Enter The Branch");
}
}else
{
	error("Enter The Semester");
}

