<?php
switch($_GET['page'])
{
	case "Theme":
theme();
break;
}
